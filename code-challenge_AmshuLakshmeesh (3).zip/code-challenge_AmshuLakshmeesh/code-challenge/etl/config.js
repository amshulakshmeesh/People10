module.exports = {
  host: 'localhost',
  user: 'amshu',
  password: 'amshu',
  database: 'etl',
};